// cosmosServis.js
const { CosmosClient } = require("@azure/cosmos");

const endpoint = process.env.COSMOS_DB_ENDPOINT;
const key = process.env.COSMOS_DB_KEY;

const client = new CosmosClient({ endpoint, key });

const database = client.database(process.env.COSMOS_DB_NAME);
const container = database.container(process.env.COSMOS_CONTAINER_NAME);

// Add metadata (image or video)
async function addImage(data) {
  if (!data.uploadedAt) {
    data.uploadedAt = new Date().toISOString();
  }

  console.log("Saving to DB:", process.env.COSMOS_DB_NAME);
  console.log("Saving to Container:", process.env.COSMOS_CONTAINER_NAME);

  const { resource } = await container.items.create(data);
  return resource;
}

// List all items
async function listImages() {
  const query = "SELECT * FROM c ORDER BY c.uploadedAt DESC";
  const { resources } = await container.items.query(query).fetchAll();
  return resources;
}

// Get single item by id
async function getImageById(id) {
  try {
    const { resource } = await container.item(id, id).read();
    return resource || null;
  } catch (err) {
    if (err.code === 404) return null;
    throw err;
  }
}

// Update existing item (for comments/ratings/etc.)
async function updateImage(item) {
  const { resource } = await container.item(item.id, item.id).replace(item);
  return resource;
}

// Delete by name (query first, then delete by id)
async function deleteImage(name) {
  const query = {
    query: "SELECT * FROM c WHERE c.name = @name",
    parameters: [{ name: "@name", value: name }],
  };

  const { resources } = await container.items.query(query).fetchAll();
  if (!resources.length) return;

  const item = resources[0];
  await container.item(item.id, item.id).delete();
}

module.exports = {
  addImage,
  listImages,
  deleteImage,
  getImageById,
  updateImage,
};
