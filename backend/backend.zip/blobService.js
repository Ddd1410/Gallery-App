const { BlobServiceClient } = require("@azure/storage-blob");

// Use the same connection string and container client
const blobServiceClient = BlobServiceClient.fromConnectionString(
  process.env.AZURE_STORAGE_CONNECTION_STRING
);
const containerClient = blobServiceClient.getContainerClient("images");

// Upload function (already exists)
async function uploadImage(file) {
  const { v4: uuidv4 } = require("uuid");
  const blobName = `${uuidv4()}-${file.originalname}`;
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);

  await blockBlobClient.uploadData(file.buffer, {
    blobHTTPHeaders: { blobContentType: file.mimetype },
  });

  return blockBlobClient.url;
}

// New: List all blobs in container
async function listImages() {
  const images = [];
  for await (const blob of containerClient.listBlobsFlat()) {
    const blobClient = containerClient.getBlobClient(blob.name);
    const url = blobClient.url;
    // Here, you can also attach metadata if stored elsewhere
    images.push({ name: blob.name, url });
  }
  return images;
}

module.exports = { uploadImage, listImages };
